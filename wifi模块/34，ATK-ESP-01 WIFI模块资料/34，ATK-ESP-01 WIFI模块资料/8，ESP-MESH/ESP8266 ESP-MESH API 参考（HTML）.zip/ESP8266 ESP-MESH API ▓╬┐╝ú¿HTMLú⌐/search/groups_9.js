var searchData=
[
  ['sensor_20apis',['Sensor APIs',['../group___sensor___a_p_is.html',1,'']]],
  ['smartconfig_20apis',['Smartconfig APIs',['../group___smartconfig___a_p_is.html',1,'']]],
  ['softap_20apis',['SoftAP APIs',['../group___soft_a_p___a_p_is.html',1,'']]],
  ['spi_20driver_20apis',['SPI Driver APIs',['../group___s_p_i___driver___a_p_is.html',1,'']]],
  ['station_20apis',['Station APIs',['../group___station___a_p_is.html',1,'']]],
  ['system_20apis',['System APIs',['../group___system___a_p_is.html',1,'']]],
  ['software_20timer_20apis',['Software timer APIs',['../group___timer___a_p_is.html',1,'']]],
  ['sniffer_20apis',['Sniffer APIs',['../group___wi_fi___sniffer___a_p_is.html',1,'']]]
];
