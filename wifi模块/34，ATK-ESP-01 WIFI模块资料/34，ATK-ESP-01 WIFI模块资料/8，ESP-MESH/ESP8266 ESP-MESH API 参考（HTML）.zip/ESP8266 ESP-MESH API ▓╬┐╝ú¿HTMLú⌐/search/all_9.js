var searchData=
[
  ['resv',['resv',['../structmesh__header__option__frag__format.html#aa89b0ed9da20d067280fc6da2519ec53',1,'mesh_header_option_frag_format']]],
  ['rsv',['rsv',['../structmesh__header__format.html#a5f419eaddbbfbee1dd46c2ef8376709d',1,'mesh_header_format']]]
];
