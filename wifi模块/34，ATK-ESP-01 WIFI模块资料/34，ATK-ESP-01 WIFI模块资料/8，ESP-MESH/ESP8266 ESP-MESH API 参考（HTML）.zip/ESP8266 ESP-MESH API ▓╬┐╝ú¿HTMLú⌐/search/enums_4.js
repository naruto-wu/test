var searchData=
[
  ['ota_5ferror_5fid',['ota_error_id',['../group__system__upgrade___a_p_is.html#ga1e8876da5916ec8c91b126453fad76f9',1,'upgrade.h']]]
];
