var searchData=
[
  ['os_5ftimer_5farm',['os_timer_arm',['../group___timer___a_p_is.html#ga26366c1af6634ad1bac5579c3cbe301d',1,'esp_timer.h']]],
  ['os_5ftimer_5fdisarm',['os_timer_disarm',['../group___timer___a_p_is.html#gae5d5bc766def32d5dbba2bb44e02fd00',1,'esp_timer.h']]],
  ['os_5ftimer_5fsetfn',['os_timer_setfn',['../group___timer___a_p_is.html#ga77b22f92e381327c7d717ab408df9967',1,'esp_timer.h']]]
];
