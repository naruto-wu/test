var indexSectionsWithContent =
{
  0: "cdegilmoprsuv",
  1: "m",
  2: "e",
  3: "cdgilmoprsuv",
  4: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Modules"
};

